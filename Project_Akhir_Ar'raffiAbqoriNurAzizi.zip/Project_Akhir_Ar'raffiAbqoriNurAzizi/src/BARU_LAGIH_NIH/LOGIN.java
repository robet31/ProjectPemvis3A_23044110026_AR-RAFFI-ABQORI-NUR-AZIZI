package BARU_LAGIH_NIH;

import Manajemen_Pertanian.Admin_Tani1;
import Manajemen_Pertanian.Admin_Tani1;
import Manajemen_Pertanian.User_Pertanian1;
import java.awt.CardLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import static javax.swing.text.html.parser.DTDConstants.ID;


public class LOGIN extends javax.swing.JFrame {
    Connection con;
    Statement st;
    
    
    
    public LOGIN() {
        initComponents();
        setTitle("Login Page untuk USER dan ADMIN");
        con = Koneksi.getConnection();
        
        
        Show.setVisible(false);
        Hide.setVisible(true);
        Show1.setVisible(false);
        Hide1.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LOGIN = new javax.swing.JPanel();
        LoginPage = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        Logo = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        Hide = new javax.swing.JLabel();
        Show = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TfUsernameLogin = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        JpPasswordLogin = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        BtnMasuk = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        JCRoleLogin = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        DaftarAkun = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Logo1 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        Show1 = new javax.swing.JLabel();
        Hide1 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        TfUsernameDaftar = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        BtnDaftarAkun = new javax.swing.JButton();
        JpPasswordDaftar = new javax.swing.JPasswordField();
        jLabel52 = new javax.swing.JLabel();
        emailAddress = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        NomorTeleponDaftar = new javax.swing.JTextField();
        VerificationSMS = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        Logo2 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        fname5 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        pass5 = new javax.swing.JPasswordField();
        jLabel44 = new javax.swing.JLabel();
        BtnMasuk2 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        fname7 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        BtnVerifikasi = new javax.swing.JButton();
        VerificationEmail = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        Logo3 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        fname4 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        pass4 = new javax.swing.JPasswordField();
        jLabel37 = new javax.swing.JLabel();
        BtnMasuk1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 480));
        setPreferredSize(new java.awt.Dimension(800, 480));

        LOGIN.setMinimumSize(new java.awt.Dimension(800, 450));
        LOGIN.setPreferredSize(new java.awt.Dimension(800, 450));
        LOGIN.setLayout(new java.awt.CardLayout());

        LoginPage.setBackground(new java.awt.Color(0, 255, 153));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));

        jLabel3.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("copyright © AgriPlants All rights reserved");

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/LOGO1.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(jLabel3))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 400, 450);

        jPanel3.setBackground(new java.awt.Color(237, 255, 235));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Hide.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Hide.setText("Hide");
        Hide.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HideMouseClicked(evt);
            }
        });
        jPanel3.add(Hide, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 60, 60));

        Show.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Show.setText("Show");
        Show.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ShowMouseClicked(evt);
            }
        });
        jPanel3.add(Show, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 60, 60));

        jLabel4.setBackground(new java.awt.Color(0, 102, 102));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("LOGIN AKUN");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 29, -1, -1));

        jLabel5.setBackground(new java.awt.Color(102, 102, 102));
        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel5.setText("Username");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        TfUsernameLogin.setBackground(new java.awt.Color(237, 255, 235));
        TfUsernameLogin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TfUsernameLogin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TfUsernameLogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        TfUsernameLogin.setCaretColor(new java.awt.Color(0, 178, 81));
        TfUsernameLogin.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        TfUsernameLogin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                TfUsernameLoginFocusGained(evt);
            }
        });
        jPanel3.add(TfUsernameLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 332, 40));

        jLabel7.setBackground(new java.awt.Color(102, 102, 102));
        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel7.setText("Pilih Login Sebagai : ");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 140, -1));

        JpPasswordLogin.setBackground(new java.awt.Color(237, 255, 235));
        JpPasswordLogin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JpPasswordLogin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        JpPasswordLogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        JpPasswordLogin.setCaretColor(new java.awt.Color(0, 178, 81));
        JpPasswordLogin.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        JpPasswordLogin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                JpPasswordLoginFocusGained(evt);
            }
        });
        jPanel3.add(JpPasswordLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 332, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel8.setText("Daftar akun dulu kalo belum punya...");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 361, -1, -1));

        BtnMasuk.setBackground(new java.awt.Color(0, 102, 102));
        BtnMasuk.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        BtnMasuk.setForeground(new java.awt.Color(255, 255, 255));
        BtnMasuk.setText("Masuk");
        BtnMasuk.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMasukActionPerformed(evt);
            }
        });
        jPanel3.add(BtnMasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 130, 40));

        jButton2.setBackground(new java.awt.Color(248, 179, 43));
        jButton2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Daftar Akun");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 354, 100, 31));

        jLabel16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel16.setText("Login pakai Nomor Telepon ...");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 398, 211, -1));

        jButton4.setBackground(new java.awt.Color(248, 179, 43));
        jButton4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Login SMS");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 391, 100, 31));

        JCRoleLogin.setBackground(new java.awt.Color(237, 255, 235));
        JCRoleLogin.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        JCRoleLogin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "                  ----Pilih Login Sebagai---- ", "                                Admin", "                                Petani" }));
        JCRoleLogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.add(JCRoleLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 330, 40));

        jLabel18.setBackground(new java.awt.Color(102, 102, 102));
        jLabel18.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel18.setText("Password");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jPanel1.add(jPanel3);
        jPanel3.setBounds(400, 0, 400, 450);

        javax.swing.GroupLayout LoginPageLayout = new javax.swing.GroupLayout(LoginPage);
        LoginPage.setLayout(LoginPageLayout);
        LoginPageLayout.setHorizontalGroup(
            LoginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginPageLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        LoginPageLayout.setVerticalGroup(
            LoginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        LOGIN.add(LoginPage, "card1");
        LoginPage.getAccessibleContext().setAccessibleName("");

        DaftarAkun.setBackground(new java.awt.Color(0, 255, 153));

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));
        jPanel20.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel20.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));

        Logo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/LOGO1.png"))); // NOI18N

        jLabel19.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(204, 204, 204));
        jLabel19.setText("copyright © AgriPlants All rights reserved");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(Logo1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel19)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(Logo1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(jLabel19))
        );

        jPanel20.add(jPanel4);
        jPanel4.setBounds(0, 0, 400, 450);

        jPanel22.setBackground(new java.awt.Color(237, 255, 235));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Show1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Show1.setText("Show");
        Show1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Show1MouseClicked(evt);
            }
        });
        jPanel22.add(Show1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 300, 60, 60));

        Hide1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Hide1.setText("Hide");
        Hide1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Hide1MouseClicked(evt);
            }
        });
        jPanel22.add(Hide1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 300, 60, 60));

        jLabel48.setBackground(new java.awt.Color(0, 102, 102));
        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel48.setText("DAFTAR AKUN");
        jPanel22.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        jLabel49.setBackground(new java.awt.Color(102, 102, 102));
        jLabel49.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel49.setText("Username");
        jPanel22.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 67, -1, -1));

        TfUsernameDaftar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TfUsernameDaftar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TfUsernameDaftar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                TfUsernameDaftarFocusGained(evt);
            }
        });
        jPanel22.add(TfUsernameDaftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 93, 332, 40));

        jLabel50.setBackground(new java.awt.Color(102, 102, 102));
        jLabel50.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel50.setText("Email");
        jPanel22.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 139, 44, -1));

        BtnDaftarAkun.setBackground(new java.awt.Color(0, 102, 102));
        BtnDaftarAkun.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        BtnDaftarAkun.setForeground(new java.awt.Color(255, 255, 255));
        BtnDaftarAkun.setText("DAFTAR");
        BtnDaftarAkun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDaftarAkunActionPerformed(evt);
            }
        });
        jPanel22.add(BtnDaftarAkun, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 381, -1, 37));

        JpPasswordDaftar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JpPasswordDaftar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        JpPasswordDaftar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                JpPasswordDaftarFocusGained(evt);
            }
        });
        jPanel22.add(JpPasswordDaftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 309, 332, 40));

        jLabel52.setBackground(new java.awt.Color(102, 102, 102));
        jLabel52.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel52.setText("Password");
        jPanel22.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 283, -1, -1));

        emailAddress.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        emailAddress.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        emailAddress.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emailAddressFocusGained(evt);
            }
        });
        jPanel22.add(emailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 165, 332, 40));

        jLabel53.setBackground(new java.awt.Color(102, 102, 102));
        jLabel53.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel53.setText("Nomor Telpon");
        jPanel22.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 211, -1, -1));

        NomorTeleponDaftar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        NomorTeleponDaftar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        NomorTeleponDaftar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                NomorTeleponDaftarFocusGained(evt);
            }
        });
        jPanel22.add(NomorTeleponDaftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 237, 332, 40));

        jPanel20.add(jPanel22);
        jPanel22.setBounds(400, 0, 400, 450);

        javax.swing.GroupLayout DaftarAkunLayout = new javax.swing.GroupLayout(DaftarAkun);
        DaftarAkun.setLayout(DaftarAkunLayout);
        DaftarAkunLayout.setHorizontalGroup(
            DaftarAkunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DaftarAkunLayout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        DaftarAkunLayout.setVerticalGroup(
            DaftarAkunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        LOGIN.add(DaftarAkun, "card2");

        VerificationSMS.setBackground(new java.awt.Color(0, 255, 153));

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel17.setLayout(null);

        jPanel6.setBackground(new java.awt.Color(0, 102, 102));

        Logo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/LOGO1.png"))); // NOI18N

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(204, 204, 204));
        jLabel20.setText("copyright © AgriPlants All rights reserved");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(Logo2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel20)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(Logo2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(jLabel20))
        );

        jPanel17.add(jPanel6);
        jPanel6.setBounds(0, 0, 400, 450);

        jPanel19.setBackground(new java.awt.Color(237, 255, 235));

        jLabel41.setBackground(new java.awt.Color(0, 102, 102));
        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel41.setText("VERIFICATION SMS");

        jLabel42.setBackground(new java.awt.Color(102, 102, 102));
        jLabel42.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel42.setText("NOMOR TELEPON");

        fname5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        fname5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fname5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fname5FocusGained(evt);
            }
        });

        jLabel43.setBackground(new java.awt.Color(102, 102, 102));
        jLabel43.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel43.setText("KODE OTP");

        pass5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        pass5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pass5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                pass5FocusGained(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel44.setText("Verifikasi pakai Email...");

        BtnMasuk2.setBackground(new java.awt.Color(0, 102, 102));
        BtnMasuk2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        BtnMasuk2.setForeground(new java.awt.Color(255, 255, 255));
        BtnMasuk2.setText("Masuk");
        BtnMasuk2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMasuk2ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 51, 51));
        jButton6.setText("Verif Email");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        fname7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        fname7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fname7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fname7FocusGained(evt);
            }
        });

        jLabel45.setBackground(new java.awt.Color(102, 102, 102));
        jLabel45.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel45.setText("Username");

        BtnVerifikasi.setBackground(new java.awt.Color(0, 102, 102));
        BtnVerifikasi.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        BtnVerifikasi.setForeground(new java.awt.Color(255, 255, 255));
        BtnVerifikasi.setText("Verifikasi");
        BtnVerifikasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnVerifikasiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel41)
                .addGap(83, 83, 83))
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnVerifikasi, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45)
                    .addComponent(fname7, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6))
                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel42)
                        .addComponent(fname5, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                        .addComponent(jLabel43)
                        .addComponent(pass5))
                    .addComponent(BtnMasuk2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fname7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fname5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BtnMasuk2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pass5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BtnVerifikasi, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29))
        );

        jPanel17.add(jPanel19);
        jPanel19.setBounds(400, 0, 400, 450);

        javax.swing.GroupLayout VerificationSMSLayout = new javax.swing.GroupLayout(VerificationSMS);
        VerificationSMS.setLayout(VerificationSMSLayout);
        VerificationSMSLayout.setHorizontalGroup(
            VerificationSMSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(VerificationSMSLayout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        VerificationSMSLayout.setVerticalGroup(
            VerificationSMSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        LOGIN.add(VerificationSMS, "card3");

        VerificationEmail.setBackground(new java.awt.Color(0, 255, 153));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel14.setLayout(null);

        jPanel7.setBackground(new java.awt.Color(0, 102, 102));

        Logo3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/LOGO1.png"))); // NOI18N

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(204, 204, 204));
        jLabel21.setText("copyright © AgriPlants All rights reserved");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(Logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel21)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(Logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(jLabel21))
        );

        jPanel14.add(jPanel7);
        jPanel7.setBounds(0, 0, 400, 450);

        jPanel16.setBackground(new java.awt.Color(237, 255, 235));

        jLabel34.setBackground(new java.awt.Color(0, 102, 102));
        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel34.setText("VERIFICATION EMAIL");

        jLabel35.setBackground(new java.awt.Color(102, 102, 102));
        jLabel35.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel35.setText("EMAIL");

        fname4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        fname4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fname4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fname4FocusGained(evt);
            }
        });

        jLabel36.setBackground(new java.awt.Color(102, 102, 102));
        jLabel36.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel36.setText("KODE OTP");

        pass4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        pass4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pass4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                pass4FocusGained(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel37.setText("Verifikasi pakai Nomor Telpon...");

        BtnMasuk1.setBackground(new java.awt.Color(0, 102, 102));
        BtnMasuk1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        BtnMasuk1.setForeground(new java.awt.Color(255, 255, 255));
        BtnMasuk1.setText("Masuk");
        BtnMasuk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMasuk1ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 51, 51));
        jButton3.setText("Verif SMS");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel35)
                                .addComponent(fname4, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                                .addComponent(jLabel36)
                                .addComponent(pass4))
                            .addComponent(BtnMasuk1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3))))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLabel34)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel34)
                .addGap(25, 25, 25)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fname4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pass4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(BtnMasuk1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jPanel14.add(jPanel16);
        jPanel16.setBounds(400, 0, 400, 450);

        javax.swing.GroupLayout VerificationEmailLayout = new javax.swing.GroupLayout(VerificationEmail);
        VerificationEmail.setLayout(VerificationEmailLayout);
        VerificationEmailLayout.setHorizontalGroup(
            VerificationEmailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(VerificationEmailLayout.createSequentialGroup()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        VerificationEmailLayout.setVerticalGroup(
            VerificationEmailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        LOGIN.add(VerificationEmail, "card4");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMasukActionPerformed
        System.out.println("Button Masuk Akun Di klik");

        String SUrl = "jdbc:mysql://localhost:3307/project_akhir_baru";
        String SUser = "root";
        String SPass = "";
        String username, password, role;

        // Validasi input kosong
        if (TfUsernameLogin.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(new JFrame(), "Username masih kosong, harap isi kembali!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JpPasswordLogin.getPassword().length == 0) {
            JOptionPane.showMessageDialog(new JFrame(), "Password masih kosong, harap isi kembali!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JCRoleLogin.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(new JFrame(), "Role belum dipilih! Silakan pilih peran Anda.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        username = TfUsernameLogin.getText().trim();
        password = new String(JpPasswordLogin.getPassword()).trim();
        role = JCRoleLogin.getSelectedItem().toString().trim();

        // Debugging input
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        System.out.println("Role: " + role);

        // Koneksi ke database
        try (Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
             PreparedStatement ps = con.prepareStatement("SELECT * FROM akun WHERE UsernameUser = ? AND PasswordUser = ? AND Role = ?")) {

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Login berhasil
                JOptionPane.showMessageDialog(this, "Selamat datang, " + rs.getString("UsernameUser") + "! Anda login sebagai " + rs.getString("Role") + ".");
                if ("Admin".equals(role)) {
                    Admin_Tani1 adminFrame = new Admin_Tani1(username);
                    adminFrame.setVisible(true);
                } else {
                    User_Pertanian1 userFrame = new User_Pertanian1(username);
                    userFrame.setVisible(true);
                }
                this.dispose();
            } else {
                // Login gagal
                JOptionPane.showMessageDialog(new JFrame(), "Username, Password, atau Role salah!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(new JFrame(), "Kesalahan koneksi database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnMasukActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        CardLayout c2 = (CardLayout) (LOGIN.getLayout());
        c2.show(LOGIN, "card2");
//        LOGIN LoginFrame = new LOGIN();
//        LoginFrame.setVisible(true);
//        LoginFrame.pack();
//        LoginFrame.setLocationRelativeTo(null);
//        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void BtnMasuk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMasuk1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnMasuk1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void BtnMasuk2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMasuk2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnMasuk2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        CardLayout c2 = (CardLayout) (LOGIN.getLayout());
        c2.show(LOGIN, "card4");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void BtnDaftarAkunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDaftarAkunActionPerformed
        // TODO add your handling code here:
        System.out.println("Button Masuk Akun Di klik");
        String username, email, telepon, Password, query;
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3307/project_akhir_baru";
        SUser = "root";
        SPass = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();

            if ("".equals(TfUsernameDaftar.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Username Masih Kosong, Harap isi kembali !!!", "Error",
                    JOptionPane.ERROR_MESSAGE);
            } else if ("".equals(JpPasswordDaftar.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Password Masih Kosong, Harap isi kembali !!!", "Error",
                    JOptionPane.ERROR_MESSAGE);
            } else if ("".equals(emailAddress.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Email Masih Kosong, Harap isi kembali !!!", "Error",
                    JOptionPane.ERROR_MESSAGE);
            } else if ("".equals(NomorTeleponDaftar.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Nomor Telepon Anda Masih Kosong, Harap isi kembali !!!", "Error",
                   JOptionPane.ERROR_MESSAGE);
            } else {
                username = TfUsernameDaftar.getText();
                Password = JpPasswordDaftar.getText();
                email = emailAddress.getText();
                telepon = NomorTeleponDaftar.getText();
                System.out.println("Username: " + username);
                System.out.println("Password: " + Password);
                System.out.println("Email : " + email);
                System.out.println("Nomor Telepon : " + telepon);

                // Adding the role 'User' to the query
                query = "INSERT INTO akun (ID, UsernameUser, EmailUser, NomorTelepon, PasswordUser, Role) VALUES (?, ?, ?, ?, ?, 'Petani')";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, ID); // Using PreparedStatement to avoid SQL Injection
                ps.setString(2, username);
                ps.setString(3, email);
                ps.setString(4, telepon);
                ps.setString(5, Password);

                ps.executeUpdate();
                TfUsernameLogin.setText("");
                JpPasswordLogin.setText("");
                emailAddress.setText("");
                NomorTeleponDaftar.setText("");
                JOptionPane.showMessageDialog(null, "Akun Baru Berhasil Ditambahkan!");
            }
        } catch (SQLException e) {
            System.out.println("Error! " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Driver tidak ditemukan! " + e.getMessage());
        }
        CardLayout c2 = (CardLayout) (LOGIN.getLayout());
        c2.show(LOGIN, "card1");
    }//GEN-LAST:event_BtnDaftarAkunActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        CardLayout c2 = (CardLayout) (LOGIN.getLayout());
        c2.show(LOGIN, "card3");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void fname4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fname4FocusGained
        // TODO add your handling code here:
        fname4.setText("");
    }//GEN-LAST:event_fname4FocusGained

    private void pass4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_pass4FocusGained
        // TODO add your handling code here:
        pass4.setText("");
    }//GEN-LAST:event_pass4FocusGained

    private void fname5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fname5FocusGained
        // TODO add your handling code here:
        fname5.setText("");
    }//GEN-LAST:event_fname5FocusGained

    private void pass5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_pass5FocusGained
        // TODO add your handling code here:
        pass5.setText("");
    }//GEN-LAST:event_pass5FocusGained

    private void TfUsernameDaftarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TfUsernameDaftarFocusGained
        // TODO add your handling code here:
        TfUsernameDaftar.setText("");
    }//GEN-LAST:event_TfUsernameDaftarFocusGained

    private void emailAddressFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailAddressFocusGained
        // TODO add your handling code here:
        emailAddress.setText("");
    }//GEN-LAST:event_emailAddressFocusGained

    private void NomorTeleponDaftarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_NomorTeleponDaftarFocusGained
        // TODO add your handling code here:
        NomorTeleponDaftar.setText("");
    }//GEN-LAST:event_NomorTeleponDaftarFocusGained

    private void JpPasswordDaftarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_JpPasswordDaftarFocusGained
        // TODO add your handling code here:
        JpPasswordDaftar.setText("");
    }//GEN-LAST:event_JpPasswordDaftarFocusGained

    private void TfUsernameLoginFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TfUsernameLoginFocusGained
        // TODO add your handling code here:
        TfUsernameLogin.setText("");
    }//GEN-LAST:event_TfUsernameLoginFocusGained

    private void JpPasswordLoginFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_JpPasswordLoginFocusGained
        // TODO add your handling code here:
        JpPasswordLogin.setText("");
    }//GEN-LAST:event_JpPasswordLoginFocusGained

    private void fname7FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fname7FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_fname7FocusGained

    private void BtnVerifikasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnVerifikasiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnVerifikasiActionPerformed

    private void ShowMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ShowMouseClicked
        // TODO add your handling code here:
        Show.setVisible(false);
        Hide.setVisible(true);
        JpPasswordLogin.setEchoChar((char)0);
    }//GEN-LAST:event_ShowMouseClicked

    private void HideMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HideMouseClicked
        // TODO add your handling code here:
        Show.setVisible(true);
        Hide.setVisible(false);
        JpPasswordLogin.setEchoChar('*');
    }//GEN-LAST:event_HideMouseClicked

    private void Show1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Show1MouseClicked
        // TODO add your handling code here:
        Show1.setVisible(false);
        Hide1.setVisible(true);
        JpPasswordDaftar.setEchoChar((char)0);
    }//GEN-LAST:event_Show1MouseClicked

    private void Hide1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Hide1MouseClicked
        // TODO add your handling code here:
        Show1.setVisible(true);
        Hide1.setVisible(false);
        JpPasswordDaftar.setEchoChar('*');
    }//GEN-LAST:event_Hide1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
//        LOGIN LoginFrame = new LOGIN();
//        LoginFrame.setVisible(true);
//        LoginFrame.pack();
//        LoginFrame.setLocationRelativeTo(null);
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LOGIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnDaftarAkun;
    private javax.swing.JButton BtnMasuk;
    private javax.swing.JButton BtnMasuk1;
    private javax.swing.JButton BtnMasuk2;
    private javax.swing.JButton BtnVerifikasi;
    private javax.swing.JPanel DaftarAkun;
    private javax.swing.JLabel Hide;
    private javax.swing.JLabel Hide1;
    private javax.swing.JComboBox<String> JCRoleLogin;
    private javax.swing.JPasswordField JpPasswordDaftar;
    private javax.swing.JPasswordField JpPasswordLogin;
    private javax.swing.JPanel LOGIN;
    private javax.swing.JPanel LoginPage;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel Logo1;
    private javax.swing.JLabel Logo2;
    private javax.swing.JLabel Logo3;
    private javax.swing.JTextField NomorTeleponDaftar;
    private javax.swing.JLabel Show;
    private javax.swing.JLabel Show1;
    private javax.swing.JTextField TfUsernameDaftar;
    private javax.swing.JTextField TfUsernameLogin;
    private javax.swing.JPanel VerificationEmail;
    private javax.swing.JPanel VerificationSMS;
    private javax.swing.JTextField emailAddress;
    private javax.swing.JTextField fname4;
    private javax.swing.JTextField fname5;
    private javax.swing.JTextField fname7;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPasswordField pass4;
    private javax.swing.JPasswordField pass5;
    // End of variables declaration//GEN-END:variables
}
