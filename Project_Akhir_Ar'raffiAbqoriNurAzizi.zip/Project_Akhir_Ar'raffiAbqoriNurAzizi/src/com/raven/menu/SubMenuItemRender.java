package com.raven.menu;

import java.awt.Component;

public interface SubMenuItemRender {

    public Component getSubMenuItemreder(Menu menu, ModelSubMenu data);
}
