package Manajemen_Pertanian;

import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import Manajemen_Pertanian.Admin_Tani1;
import java.awt.Container;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.table.DefaultTableModel;

public class Admin_Tani1 extends javax.swing.JFrame {
    Connection konek;
    private DefaultTableModel model1;
    private Container User_Pertanian1;

    public Admin_Tani1() {
        initComponents();
        User_Pertanian1 = this.getContentPane();
        konek = Koneksi.getConnection();
        
        model1 = new DefaultTableModel();
        TBLJadwalPanen.setModel(model1);
        model1.addColumn("ID");
        model1.addColumn("Tanggal");
        model1.addColumn("Kegiatan");
        model1.addColumn("Status");
        model1.addColumn("Lahan_ID");
        JadwalPertanian();
    }
    
    public Admin_Tani1(String username) {
        initComponents();
        setTitle("ADMIN MANAJEMEN PERTANIAN");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jLabel1.setText(username);
        jLabel6.setText(username);
    }
    
    private void JadwalPertanian(){
        model1.setRowCount(0);  
        try {  
            String sql = "SELECT * FROM jadwal"; // Pastikan nama tabel benar  
            PreparedStatement ps = konek.prepareStatement(sql);  
            ResultSet rs = ps.executeQuery();  
            while (rs.next()) {  
                model1.addRow(new Object[]{  
                    rs.getInt("ID"), // Pastikan kolom ID ada di tabel  
                    rs.getString("Tanggal"), // Pastikan kolom Tanggal ada di tabel  
                    rs.getString("Kegiatan"), // Pastikan kolom Kegiatan ada di tabel  
                    rs.getString("Status"), // Pastikan kolom Status ada di tabel  
                    rs.getInt("Lahan_ID") // Pastikan kolom Lahan_ID ada di tabel  
                });  
            }  
        } catch (SQLException e) {  
            System.out.println("Error Save Data: " + e.getMessage());  
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        PanelCard = new javax.swing.JPanel();
        JadwalPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TBLJadwalPanen = new javax.swing.JTable();
        jButton9 = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jComboBox1 = new javax.swing.JComboBox<>();
        ManajemenPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        EdukasiPanel = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        CuacaPanel = new javax.swing.JPanel();
        MarketplacePanel = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        DashboardPanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cbMelon = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        cbTanah = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cbPupuk = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        tfTanam = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tfPanen = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        alertMelon = new javax.swing.JLabel();
        alertTanah = new javax.swing.JLabel();
        alertPupuk = new javax.swing.JLabel();
        alertTanam = new javax.swing.JLabel();
        alertPanen = new javax.swing.JLabel();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jDateChooser3 = new com.toedter.calendar.JDateChooser();
        Judul = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Logos = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        SideBarUp = new javax.swing.JPanel();
        ProfileUser = new javax.swing.JLabel();
        REKOMENDASI = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        BackToMenu = new javax.swing.JLabel();
        SideBarDown = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setMinimumSize(new java.awt.Dimension(770, 485));
        setPreferredSize(new java.awt.Dimension(770, 485));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelCard.setBackground(new java.awt.Color(204, 204, 0));
        PanelCard.setForeground(new java.awt.Color(153, 153, 0));
        PanelCard.setOpaque(false);
        PanelCard.setLayout(new java.awt.CardLayout());

        JadwalPanel.setBackground(new java.awt.Color(255, 255, 102));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Pilih Tanggal Tanam/Panen : ");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Pilih Kegiatan (Tanam/Panen) : ");

        TBLJadwalPanen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        jScrollPane2.setViewportView(TBLJadwalPanen);

        jButton9.setText("Tambah Jadwal");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jDateChooser1.setMinimumSize(new java.awt.Dimension(102, 42));

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Kegiatan", "Tanam", "Panen" }));

        javax.swing.GroupLayout JadwalPanelLayout = new javax.swing.GroupLayout(JadwalPanel);
        JadwalPanel.setLayout(JadwalPanelLayout);
        JadwalPanelLayout.setHorizontalGroup(
            JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JadwalPanelLayout.createSequentialGroup()
                .addGroup(JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JadwalPanelLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(JadwalPanelLayout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(JadwalPanelLayout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(JadwalPanelLayout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(199, Short.MAX_VALUE))
        );
        JadwalPanelLayout.setVerticalGroup(
            JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JadwalPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JadwalPanelLayout.createSequentialGroup()
                        .addGroup(JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(JadwalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13))
        );

        PanelCard.add(JadwalPanel, "card3");

        ManajemenPanel.setBackground(new java.awt.Color(0, 153, 153));
        ManajemenPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Manajemen Keuangan Pertanian");
        ManajemenPanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 16, 418, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Pilih Jenis Transaksi : ");
        ManajemenPanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 67, -1, 30));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Jumlah Transaksi : ");
        ManajemenPanel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 108, 141, 30));

        jButton10.setText("Simpan Transaksi");
        ManajemenPanel.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 67, -1, 71));

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Tabel Keuangan");
        ManajemenPanel.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(242, 145, 182, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jenis Transaksi", "Pemasukan", "Pengeluaran" }));
        ManajemenPanel.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(242, 67, 208, 29));
        ManajemenPanel.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(242, 108, 208, 28));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        ManajemenPanel.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 177, 520, 190));

        PanelCard.add(ManajemenPanel, "card5");

        EdukasiPanel.setBackground(new java.awt.Color(255, 102, 204));
        EdukasiPanel.setMinimumSize(new java.awt.Dimension(770, 359));
        EdukasiPanel.setPreferredSize(new java.awt.Dimension(770, 438));
        EdukasiPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText(" Daftar Data Tanaman");
        EdukasiPanel.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Cari Data Tanaman : ");
        EdukasiPanel.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("MANAJEMEN PERAWATAN TANAMAN");
        EdukasiPanel.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 504, -1));

        EdukasiPanel.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 238, 26));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Tanaman", "Jumlah Pupuk", "Jumlah Bibit", "Jenis Perawatan", "Tanggal Perawatan"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        EdukasiPanel.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 630, 199));

        PanelCard.add(EdukasiPanel, "card7");

        CuacaPanel.setBackground(new java.awt.Color(0, 255, 204));

        javax.swing.GroupLayout CuacaPanelLayout = new javax.swing.GroupLayout(CuacaPanel);
        CuacaPanel.setLayout(CuacaPanelLayout);
        CuacaPanelLayout.setHorizontalGroup(
            CuacaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 830, Short.MAX_VALUE)
        );
        CuacaPanelLayout.setVerticalGroup(
            CuacaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );

        PanelCard.add(CuacaPanel, "card4");

        MarketplacePanel.setBackground(new java.awt.Color(255, 51, 255));

        jLabel20.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Aplikasi Pengelolaan Pertanian");

        jLabel21.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Aplikasi Pengelolaan Pertanian");

        jButton1.setText("Tambah Produk");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton7.setText("Kembali ke Dashboard");

        jButton8.setText("Hapus Produk");

        javax.swing.GroupLayout MarketplacePanelLayout = new javax.swing.GroupLayout(MarketplacePanel);
        MarketplacePanel.setLayout(MarketplacePanelLayout);
        MarketplacePanelLayout.setHorizontalGroup(
            MarketplacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MarketplacePanelLayout.createSequentialGroup()
                .addGroup(MarketplacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MarketplacePanelLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MarketplacePanelLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(MarketplacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(MarketplacePanelLayout.createSequentialGroup()
                                .addGroup(MarketplacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(MarketplacePanelLayout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(MarketplacePanelLayout.createSequentialGroup()
                                        .addGap(66, 66, 66)
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MarketplacePanelLayout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(115, 115, 115))
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MarketplacePanelLayout.createSequentialGroup()
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(59, 59, 59)))))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        MarketplacePanelLayout.setVerticalGroup(
            MarketplacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MarketplacePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        PanelCard.add(MarketplacePanel, "card6");

        DashboardPanel.setBackground(new java.awt.Color(204, 102, 255));
        DashboardPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Halo, ");
        DashboardPanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 6, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DashboardPanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(959, 6, 70, 32));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Selamat Datang di Dashboard Pertanian.");
        DashboardPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(181, 6, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel18.setText("Jenis Melon :");
        DashboardPanel.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 58, 169, -1));

        cbMelon.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbMelonItemStateChanged(evt);
            }
        });
        cbMelon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbMelonActionPerformed(evt);
            }
        });
        cbMelon.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cbMelonKeyReleased(evt);
            }
        });
        DashboardPanel.add(cbMelon, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 56, 425, 34));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel19.setText("Jenis Tanah :");
        DashboardPanel.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 110, 169, -1));

        cbTanah.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbTanahItemStateChanged(evt);
            }
        });
        cbTanah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cbTanahKeyReleased(evt);
            }
        });
        DashboardPanel.add(cbTanah, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 108, 425, 34));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel22.setText("Jenis Pupuk :");
        DashboardPanel.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 162, 169, -1));

        cbPupuk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbPupukItemStateChanged(evt);
            }
        });
        cbPupuk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cbPupukKeyReleased(evt);
            }
        });
        DashboardPanel.add(cbPupuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 160, 425, 34));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel23.setText("Tanggal Tanam :");
        DashboardPanel.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 214, 169, -1));

        tfTanam.setText("Tanggal Tanam");
        tfTanam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tfTanamMouseClicked(evt);
            }
        });
        tfTanam.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                tfTanamInputMethodTextChanged(evt);
            }
        });
        tfTanam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTanamActionPerformed(evt);
            }
        });
        tfTanam.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tfTanamPropertyChange(evt);
            }
        });
        tfTanam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfTanamKeyReleased(evt);
            }
        });
        DashboardPanel.add(tfTanam, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 100, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Tanggal Panen :");
        DashboardPanel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 267, 169, -1));

        tfPanen.setText("Tanggal Panen");
        tfPanen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tfPanenMouseClicked(evt);
            }
        });
        tfPanen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPanenActionPerformed(evt);
            }
        });
        tfPanen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfPanenKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfPanenKeyReleased(evt);
            }
        });
        DashboardPanel.add(tfPanen, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 350, 120, 20));

        jButton11.setBackground(new java.awt.Color(255, 51, 51));
        jButton11.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton11.setText("Reset");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        DashboardPanel.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 332, 110, 43));

        jButton12.setBackground(new java.awt.Color(0, 113, 45));
        jButton12.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton12.setText("Tambah");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        DashboardPanel.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 332, -1, 43));

        alertMelon.setForeground(new java.awt.Color(255, 0, 0));
        alertMelon.setText("..............");
        DashboardPanel.add(alertMelon, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, -1));

        alertTanah.setForeground(new java.awt.Color(255, 0, 0));
        alertTanah.setText(".......................");
        DashboardPanel.add(alertTanah, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, -1, -1));

        alertPupuk.setForeground(new java.awt.Color(255, 0, 0));
        alertPupuk.setText("....................");
        DashboardPanel.add(alertPupuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, -1, -1));

        alertTanam.setForeground(new java.awt.Color(255, 0, 0));
        alertTanam.setText("..............");
        alertTanam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                alertTanamKeyReleased(evt);
            }
        });
        DashboardPanel.add(alertTanam, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, -1, -1));

        alertPanen.setForeground(new java.awt.Color(255, 0, 0));
        alertPanen.setText("..............");
        alertPanen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                alertPanenKeyReleased(evt);
            }
        });
        DashboardPanel.add(alertPanen, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, -1, -1));
        DashboardPanel.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 270, 420, 30));

        jDateChooser3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jDateChooser3KeyReleased(evt);
            }
        });
        DashboardPanel.add(jDateChooser3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 212, 420, 30));

        PanelCard.add(DashboardPanel, "card2");

        jPanel1.add(PanelCard, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 830, 390));

        Judul.setBackground(new java.awt.Color(237, 255, 235));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Aplikasi Pengelolaan Pertanian");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Haii, Welcome ");

        javax.swing.GroupLayout JudulLayout = new javax.swing.GroupLayout(Judul);
        Judul.setLayout(JudulLayout);
        JudulLayout.setHorizontalGroup(
            JudulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JudulLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(247, Short.MAX_VALUE))
        );
        JudulLayout.setVerticalGroup(
            JudulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JudulLayout.createSequentialGroup()
                .addGroup(JudulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JudulLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(JudulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                            .addComponent(jLabel3)))
                    .addGroup(JudulLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel1.add(Judul, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 0, 890, 60));

        Logos.setBackground(new java.awt.Color(237, 255, 235));
        Logos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/LogoSideBar.png"))); // NOI18N
        Logos.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, 96));

        jPanel1.add(Logos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 110));

        SideBarUp.setBackground(new java.awt.Color(255, 102, 204));
        SideBarUp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ProfileUser.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ProfileUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProfileUser.setText("Profile User");
        ProfileUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProfileUserMouseClicked(evt);
            }
        });
        SideBarUp.add(ProfileUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 40));

        REKOMENDASI.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        REKOMENDASI.setText("EDUKASI");
        REKOMENDASI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                REKOMENDASIActionPerformed(evt);
            }
        });
        SideBarUp.add(REKOMENDASI, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 110, 40));

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("DASHBOARD");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        SideBarUp.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 110, 40));

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("JADWAL");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        SideBarUp.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 110, 40));

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setText("CUACA");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        SideBarUp.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 110, 40));

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton5.setText("MANAJEMEN");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        SideBarUp.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 110, 40));

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton6.setText("MARKETPLACE");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        SideBarUp.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 110, 40));

        jPanel1.add(SideBarUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 110, 340));

        BackToMenu.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BackToMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BackToMenu.setText("Back");
        BackToMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackToMenuMouseClicked(evt);
            }
        });
        jPanel1.add(BackToMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 110, 40));

        SideBarDown.setBackground(new java.awt.Color(153, 204, 0));

        javax.swing.GroupLayout SideBarDownLayout = new javax.swing.GroupLayout(SideBarDown);
        SideBarDown.setLayout(SideBarDownLayout);
        SideBarDownLayout.setHorizontalGroup(
            SideBarDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );
        SideBarDownLayout.setVerticalGroup(
            SideBarDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );

        jPanel1.add(SideBarDown, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 110, 340));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 757, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    int x = 110;
    private void ProfileUserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProfileUserMouseClicked
        // TODO add your handling code here:
        if ( x == 110 ){
            SideBarUp.setSize(110, 340);
            Thread th = new Thread() {
                @Override
                public void run(){
                    try{
                        for (int i = 110; i >= 0; i--){
                            Thread.sleep(1);
                            SideBarUp.setSize(i, 340);
                        }
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            }; th.start();
            x=0;
        }
    }//GEN-LAST:event_ProfileUserMouseClicked

    private void BackToMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackToMenuMouseClicked
        // TODO add your handling code here:
        if ( x == 0 ){
            SideBarUp.show();
            SideBarUp.setSize(x, 340);
            Thread th = new Thread() {
                @Override
                public void run(){
                    try{
                        for (int i = 0; i <= x; i++){
                            Thread.sleep(1);
                            SideBarUp.setSize(i, 340);
                        }
                    } catch (Exception e){
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            }; th.start();
            x=110;
        }
    }//GEN-LAST:event_BackToMenuMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card2");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card3");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card4");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card5");
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card6");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void REKOMENDASIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REKOMENDASIActionPerformed
        CardLayout c2 = (CardLayout) (PanelCard.getLayout());
        c2.show(PanelCard, "card8");
    }//GEN-LAST:event_REKOMENDASIActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        Date selectedDate = jDateChooser1.getDate();  
        String kegiatan = (String) jComboBox1.getSelectedItem();  
        String status = "Belum"; // Status default  
//        int lahanId = getSelectedLahanId()

        if (selectedDate != null && kegiatan != null) {  
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
            String formattedDate = sdf.format(selectedDate);  

            // Menambahkan baris ke model tabel  
            model1.addRow(new Object[]{null, formattedDate, kegiatan, status, null});  

            // Menyimpan data ke database  
            try {  
                String sql = "INSERT INTO jadwal (Tanggal, Kegiatan, Status) VALUES (?, ?, ?)";  
                PreparedStatement ps = konek.prepareStatement(sql);  
                ps.setString(1, formattedDate);  
                ps.setString(2, kegiatan);  
                ps.setString(3, status);  
                ps.executeUpdate(); // Eksekusi query  
                JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");  
            } catch (SQLException e) {  
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());  
            }  
        } else {  
            JOptionPane.showMessageDialog(null, "Silakan pilih tanggal dan kegiatan.");  
        }  
        JadwalPertanian();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        int row = TBLJadwalPanen.getSelectedRow();   
    
        if (row != -1) {  
            // Mengambil tanggal dari kolom yang sesuai (kolom 1 adalah Tanggal)  
            String tanggalString = TBLJadwalPanen.getValueAt(row, 1).toString();  
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Format tanggal sesuai dengan format yang digunakan  
            try {  
                Date tanggal = sdf.parse(tanggalString); // Mengubah String menjadi Date  
                jDateChooser1.setDate(tanggal); // Mengatur tanggal di jDateChooser  
            } catch (ParseException e) {  
                e.printStackTrace(); // Menangani kesalahan parsing  
            }  

            // Mengambil kegiatan dari kolom yang sesuai (kolom 2 adalah Kegiatan)  
            String kegiatan = TBLJadwalPanen.getValueAt(row, 2).toString();  
            jComboBox1.setSelectedItem(kegiatan); // Mengatur item yang dipilih di jComboBox  
        }
    }//GEN-LAST:event_jTable3MouseClicked

    private void cbMelonItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbMelonItemStateChanged
        // TODO add your handling code here:
        if(!(cbMelon.getSelectedItem() == null)){
            alertMelon.setText(" ");
        }
        rekomendasi();
    }//GEN-LAST:event_cbMelonItemStateChanged

    private void cbMelonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMelonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbMelonActionPerformed

    private void cbMelonKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cbMelonKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_cbMelonKeyReleased

    private void cbTanahItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbTanahItemStateChanged
        // TODO add your handling code here:
        if(!(cbTanah.getSelectedItem() == null)){
            alertTanah.setText(" ");
        }
        rekomendasi();
    }//GEN-LAST:event_cbTanahItemStateChanged

    private void cbTanahKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cbTanahKeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_cbTanahKeyReleased

    private void cbPupukItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbPupukItemStateChanged
        // TODO add your handling code here:
        if(!(cbPupuk.getSelectedItem() == null)){
            alertPupuk.setText(" ");
        }
        rekomendasi();
    }//GEN-LAST:event_cbPupukItemStateChanged

    private void cbPupukKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cbPupukKeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_cbPupukKeyReleased

    private void tfTanamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfTanamMouseClicked
        // TODO add your handling code here:
        chooserTanam.showPopup();
    }//GEN-LAST:event_tfTanamMouseClicked

    private void tfTanamInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_tfTanamInputMethodTextChanged
        // TODO add your handling code here:
        if(!tfTanam.getText().isEmpty()){
            alertTanam.setText(" ");
        }
    }//GEN-LAST:event_tfTanamInputMethodTextChanged

    private void tfTanamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTanamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTanamActionPerformed

    private void tfTanamPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tfTanamPropertyChange
        // TODO add your handling code here:

    }//GEN-LAST:event_tfTanamPropertyChange

    private void tfTanamKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfTanamKeyReleased
        // TODO add your handling code here:
        if(!tfTanam.getText().isEmpty()){
            alertTanam.setText(" ");
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            // TODO add your handling code here:

            Date tanam = dateFormat.parse(tfTanam.getText());
            Date panen = dateFormat.parse(tfPanen.getText());
            if(!tanam.before(panen)){
                alertPanen.setText("Gak logis Broo");
            }
            else{
                alertPanen.setText(" ");
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Format tanggal salah! Gunakan format dd-MM-yyyy", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_tfTanamKeyReleased

    private void tfPanenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfPanenMouseClicked
        // TODO add your handling code here:
        chooserPanen.showPopup();
    }//GEN-LAST:event_tfPanenMouseClicked

    private void tfPanenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPanenActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_tfPanenActionPerformed

    private void tfPanenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfPanenKeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_tfPanenKeyPressed

    private void tfPanenKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfPanenKeyReleased
        // TODO add your handling code here:
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            Date tanam = dateFormat.parse(tfTanam.getText());

            Date panen = dateFormat.parse(tfPanen.getText());
            if(!tanam.before(panen)){
                alertPanen.setText("Gak logis Broo");
            }
            else{
                alertPanen.setText(" ");
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Format tanggal salah! Gunakan format dd-MM-yyyy", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_tfPanenKeyReleased

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        reset();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        if (cbMelon.getSelectedItem() == null
            || cbPupuk.getSelectedItem() == null
            || cbTanah.getSelectedItem() == null
            || tfTanam.getText().isEmpty()
            || tfPanen.getText().isEmpty()) {
            if(cbMelon.getSelectedItem() == null){
                alertMelon.setText("Tentukan melon terlebih dahulu");
            }
            if(cbTanah.getSelectedItem() == null){
                alertTanah.setText("Tentukan tanah terlebih dahulu");
            }
            if(cbPupuk.getSelectedItem() == null){
                alertPupuk.setText("Tentukan pupuk terlebih dahulu");
            }
            if(tfTanam.getText().isEmpty()){
                alertTanam.setText("Tentukan tanggal tanam dahulu");
            }
            if(tfPanen.getText().isEmpty()){
                alertPanen.setText("Tentukan tanggal panen dahulu");
            }
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            dateFormat.setLenient(false);

            Date tanam;
            Date panen;
            try {
                tanam = dateFormat.parse(tfTanam.getText());
                panen = dateFormat.parse(tfPanen.getText());
                if(!tanam.before(panen)){
                    alertPanen.setText("Gak logis Broo");
                    return;
                }
            } catch (ParseException ex) {
                Logger.getLogger(mainPage.class.getName()).log(Level.SEVERE, null, ex);
            }

            String namaBuah = (String) cbMelon.getSelectedItem();
            buah = melon.getIdByNama(namaBuah);

            String namaPupuk = (String) cbPupuk.getSelectedItem();
            pupuk = pupuk.getIdByNama(namaPupuk);

            String namaTanah = (String) cbTanah.getSelectedItem();
            tanah = tanah.getIdByNama(namaTanah);
            try {
                dateFormat.setLenient(false);
                //      String txfTanam = tfTanam.getText();
                //      String tanamUpdate = txfTanam.replace("-", "/");
                //      Date tanam = dateFormat.parse(tfTanam.getText());
                java.util.Date tanggalTanamBefore = dateFormat.parse(tfTanam.getText());
                java.sql.Date tanggalTanam = new java.sql.Date(tanggalTanamBefore.getTime());
                java.util.Date tanggalPanenBefore = dateFormat.parse(tfPanen.getText());
                java.sql.Date tanggalPanen = new java.sql.Date(tanggalPanenBefore.getTime());
                String sql = "INSERT INTO tanam VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (Connection conn = Koneksi.getConnection();
                    PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setNull(1, 0);
                    ps.setDate(2, tanggalTanam);
                    ps.setDate(3, tanggalPanen);
                    ps.setInt(4, user.getId());
                    ps.setInt(5, buah.getId_melon());
                    ps.setInt(6, pupuk.getId_pupuk());
                    ps.setInt(7, tanah.getId_tanah());
                    ps.setString(8, "Belum dipanen");
                    ps.setInt(9, 0);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Tambah berhasil...");
                } catch (SQLException e) {
                    System.out.println("Error Tambah Data di:" + e.getMessage());
                }
                reset();
            } catch (ParseException ex) {
                Logger.getLogger(mainPage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void alertTanamKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_alertTanamKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_alertTanamKeyReleased

    private void alertPanenKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_alertPanenKeyReleased

    }//GEN-LAST:event_alertPanenKeyReleased

    private void jDateChooser3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDateChooser3KeyReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jDateChooser3KeyReleased

    
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_Tani1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_Tani1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_Tani1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_Tani1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_Tani1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackToMenu;
    private javax.swing.JPanel CuacaPanel;
    private javax.swing.JPanel DashboardPanel;
    private javax.swing.JPanel EdukasiPanel;
    private javax.swing.JPanel JadwalPanel;
    private javax.swing.JPanel Judul;
    private javax.swing.JPanel Logos;
    private javax.swing.JPanel ManajemenPanel;
    private javax.swing.JPanel MarketplacePanel;
    private javax.swing.JPanel PanelCard;
    private javax.swing.JLabel ProfileUser;
    private javax.swing.JButton REKOMENDASI;
    private javax.swing.JPanel SideBarDown;
    private javax.swing.JPanel SideBarUp;
    private javax.swing.JTable TBLJadwalPanen;
    private javax.swing.JLabel alertMelon;
    private javax.swing.JLabel alertPanen;
    private javax.swing.JLabel alertPupuk;
    private javax.swing.JLabel alertTanah;
    private javax.swing.JLabel alertTanam;
    private javax.swing.JComboBox<String> cbMelon;
    private javax.swing.JComboBox<String> cbPupuk;
    private javax.swing.JComboBox<String> cbTanah;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private com.toedter.calendar.JDateChooser jDateChooser3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField tfPanen;
    private javax.swing.JTextField tfTanam;
    // End of variables declaration//GEN-END:variables
}
