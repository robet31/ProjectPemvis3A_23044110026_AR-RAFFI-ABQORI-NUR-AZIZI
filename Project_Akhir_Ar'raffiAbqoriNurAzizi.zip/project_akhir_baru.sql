-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Waktu pembuatan: 22 Nov 2024 pada 16.56
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_akhir_baru`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `ID` int(11) NOT NULL,
  `UsernameUser` varchar(255) DEFAULT NULL,
  `EmailUser` varchar(255) DEFAULT NULL,
  `NomorTelepon` varchar(15) DEFAULT NULL,
  `PasswordUser` varchar(255) DEFAULT NULL,
  `Role` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`ID`, `UsernameUser`, `EmailUser`, `NomorTelepon`, `PasswordUser`, `Role`) VALUES
(1, 'user1', 'user1@example.com', '081234567890', 'password123', 'Petani'),
(2, 'ADMIN01', 'admin@gmail.com', '081515450611', '1234', 'Admin'),
(4, 'rafi qori', 'sopoh@gmail.com', '081515450611', '12345', 'Petani');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cuaca`
--

CREATE TABLE `cuaca` (
  `ID` int(11) NOT NULL,
  `Tanggal` date DEFAULT NULL,
  `Suhu` float DEFAULT NULL,
  `Kelembapan` float DEFAULT NULL,
  `Kondisi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `edukasi`
--

CREATE TABLE `edukasi` (
  `ID` int(11) NOT NULL,
  `Judul` varchar(255) DEFAULT NULL,
  `Kategori` varchar(255) DEFAULT NULL,
  `Konten` text DEFAULT NULL,
  `Tanggal_Dibuat` date DEFAULT NULL,
  `Admin_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `ID` int(11) NOT NULL,
  `Tanggal` date DEFAULT NULL,
  `Kegiatan` varchar(50) DEFAULT NULL CHECK (`Kegiatan` in ('Tanam','Panen')),
  `Status` varchar(50) DEFAULT NULL CHECK (`Status` in ('Belum','Selesai')),
  `Lahan_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`ID`, `Tanggal`, `Kegiatan`, `Status`, `Lahan_ID`) VALUES
(1, '2024-11-23', 'Panen', 'Belum', NULL),
(2, '2024-11-20', 'Panen', 'Belum', NULL),
(3, '2024-11-25', 'Panen', 'Belum', NULL),
(4, '2024-11-21', 'Tanam', 'Belum', NULL),
(5, '2024-11-21', 'Tanam', 'Belum', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `keuangan`
--

CREATE TABLE `keuangan` (
  `ID` int(11) NOT NULL,
  `Tanggal` date DEFAULT NULL,
  `Jenis` varchar(50) DEFAULT NULL CHECK (`Jenis` in ('Pengeluaran','Pemasukan')),
  `Jumlah` float DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `lahan`
--

CREATE TABLE `lahan` (
  `ID` int(11) NOT NULL,
  `Luas` float DEFAULT NULL,
  `Lokasi` varchar(255) DEFAULT NULL,
  `Jenis_Tanaman` varchar(255) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL CHECK (`Status` in ('Siap','Proses')),
  `User_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `marketplace`
--

CREATE TABLE `marketplace` (
  `ID_Produk` int(11) NOT NULL,
  `Nama_Produk` varchar(255) DEFAULT NULL,
  `Harga` float DEFAULT NULL,
  `Stok` int(11) DEFAULT NULL,
  `Deskripsi` text DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekomendasi`
--

CREATE TABLE `rekomendasi` (
  `ID` int(11) NOT NULL,
  `Nama_Tanaman` varchar(255) DEFAULT NULL,
  `Alasan` text DEFAULT NULL,
  `Rekomendasi` text DEFAULT NULL,
  `Cuaca_ID` int(11) DEFAULT NULL,
  `Lahan_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tanam1`
--

CREATE TABLE `tanam1` (
  `id_tanam` int(11) NOT NULL,
  `tanggal_tanam` date NOT NULL,
  `tanggal_panen` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_melon` int(11) NOT NULL,
  `id_pupuk` int(11) NOT NULL,
  `id_tanah` int(11) NOT NULL,
  `status` enum('Belum dipanen','Sudah dipanen') NOT NULL,
  `hasil_panen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tanam1`
--

INSERT INTO `tanam1` (`id_tanam`, `tanggal_tanam`, `tanggal_panen`, `id_user`, `id_melon`, `id_pupuk`, `id_tanah`, `status`, `hasil_panen`) VALUES
(1, '2024-11-06', '2024-11-07', 1, 1, 1, 1, 'Sudah dipanen', 150),
(2, '2024-11-13', '2024-11-21', 1, 1, 2, 1, 'Sudah dipanen', 305),
(3, '2024-11-13', '2024-11-21', 1, 2, 1, 3, 'Belum dipanen', 0),
(4, '2024-11-21', '2024-11-22', 1, 2, 1, 3, 'Belum dipanen', 0),
(5, '2024-11-12', '2024-11-15', 1, 4, 3, 1, 'Belum dipanen', 0),
(7, '2024-11-14', '2024-11-24', 1, 1, 2, 3, 'Belum dipanen', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user1`
--

CREATE TABLE `user1` (
  `ID` int(11) NOT NULL,
  `Nama` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Peran` varchar(50) DEFAULT NULL CHECK (`Peran` in ('Admin','Petani')),
  `Akun_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user1`
--

INSERT INTO `user1` (`ID`, `Nama`, `Email`, `Password`, `Peran`, `Akun_ID`) VALUES
(1, 'User Pertama', 'user1@example.com', 'password123', 'Petani', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks untuk tabel `cuaca`
--
ALTER TABLE `cuaca`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks untuk tabel `edukasi`
--
ALTER TABLE `edukasi`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Admin_ID` (`Admin_ID`);

--
-- Indeks untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Lahan_ID` (`Lahan_ID`);

--
-- Indeks untuk tabel `keuangan`
--
ALTER TABLE `keuangan`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indeks untuk tabel `lahan`
--
ALTER TABLE `lahan`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indeks untuk tabel `marketplace`
--
ALTER TABLE `marketplace`
  ADD PRIMARY KEY (`ID_Produk`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indeks untuk tabel `rekomendasi`
--
ALTER TABLE `rekomendasi`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Cuaca_ID` (`Cuaca_ID`),
  ADD KEY `Lahan_ID` (`Lahan_ID`);

--
-- Indeks untuk tabel `tanam1`
--
ALTER TABLE `tanam1`
  ADD PRIMARY KEY (`id_tanam`),
  ADD KEY `id_melon` (`id_melon`,`id_pupuk`,`id_tanah`),
  ADD KEY `id_pupuk` (`id_pupuk`),
  ADD KEY `id_tanah` (`id_tanah`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `user1`
--
ALTER TABLE `user1`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Akun_ID` (`Akun_ID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akun`
--
ALTER TABLE `akun`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `cuaca`
--
ALTER TABLE `cuaca`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `edukasi`
--
ALTER TABLE `edukasi`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `keuangan`
--
ALTER TABLE `keuangan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `lahan`
--
ALTER TABLE `lahan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `marketplace`
--
ALTER TABLE `marketplace`
  MODIFY `ID_Produk` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `rekomendasi`
--
ALTER TABLE `rekomendasi`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tanam1`
--
ALTER TABLE `tanam1`
  MODIFY `id_tanam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `user1`
--
ALTER TABLE `user1`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `edukasi`
--
ALTER TABLE `edukasi`
  ADD CONSTRAINT `edukasi_ibfk_1` FOREIGN KEY (`Admin_ID`) REFERENCES `user1` (`ID`);

--
-- Ketidakleluasaan untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`Lahan_ID`) REFERENCES `lahan` (`ID`);

--
-- Ketidakleluasaan untuk tabel `keuangan`
--
ALTER TABLE `keuangan`
  ADD CONSTRAINT `keuangan_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user1` (`ID`);

--
-- Ketidakleluasaan untuk tabel `lahan`
--
ALTER TABLE `lahan`
  ADD CONSTRAINT `lahan_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user1` (`ID`);

--
-- Ketidakleluasaan untuk tabel `marketplace`
--
ALTER TABLE `marketplace`
  ADD CONSTRAINT `marketplace_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user1` (`ID`);

--
-- Ketidakleluasaan untuk tabel `rekomendasi`
--
ALTER TABLE `rekomendasi`
  ADD CONSTRAINT `rekomendasi_ibfk_1` FOREIGN KEY (`Cuaca_ID`) REFERENCES `cuaca` (`ID`),
  ADD CONSTRAINT `rekomendasi_ibfk_2` FOREIGN KEY (`Lahan_ID`) REFERENCES `lahan` (`ID`);

--
-- Ketidakleluasaan untuk tabel `user1`
--
ALTER TABLE `user1`
  ADD CONSTRAINT `user1_ibfk_1` FOREIGN KEY (`Akun_ID`) REFERENCES `akun` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
